package ventas;

import formularios.Frm_Ventas;

public class Cls_main {
    public static void main(String[] args){
        Frm_Ventas fv = new Frm_Ventas();
        fv.setVisible(true);
    }
}
